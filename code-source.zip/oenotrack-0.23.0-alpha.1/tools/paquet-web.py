# Paquet « Œnotrack en ligne » : dist/web/oenotrack-web/ (index.html complet, config.json, LISEZ-MOI.txt) + zip
import os, json, zipfile, re
racine = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = open(os.path.join(racine, 'dist', 'cuverie.html'), encoding='utf8').read()
version = re.search(r"const APP_VERSION = '([^']+)'", open(os.path.join(racine, 'src', '10-core.js'), encoding='utf8').read()).group(1)
# icône d'onglet : le logo du modèle de base (tools/icones/icone.svg, rendu en PNG par tools/icones.mjs)
import urllib.parse
icone = 'data:image/svg+xml,' + urllib.parse.quote(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icones', 'icone.svg'), encoding='utf8').read().replace('\n', ''), safe="=:/'(),.-")
dossier = os.path.join(racine, 'dist', 'web', 'oenotrack-web'); os.makedirs(dossier, exist_ok=True)
cfg = os.path.join(dossier, 'config.json')
if not os.path.exists(cfg) or os.environ.get('CONFIG_VIDE'):
    json.dump({"google": {"clientId": ""}, "microsoft": {"clientId": ""}, "dropbox": {"appKey": ""}}, open(cfg, 'w', encoding='utf8'), indent=2)
# pages fixes (0.23.0-alpha.1) : informations légales et page d'accueil lisibles sans JavaScript, rendues par Œnotrack lui-même
# (tools/pages-statiques.mjs, Playwright) avec le config.json du paquet ; sans Playwright, le paquet se fait sans elles
import subprocess
PAGES_FIXES = ['mentions-legales.html', 'confidentialite.html', 'cgu.html', 'licence.html']
noscript = ''
try:
    r = subprocess.run(['node', os.path.join(racine, 'tools', 'pages-statiques.mjs'), dossier], capture_output=True, text=True, timeout=300)
    fa = os.path.join(dossier, 'accueil-noscript.html')
    if r.returncode == 0 and os.path.exists(fa): noscript = open(fa, encoding='utf8').read(); print(r.stdout.strip())
    else: print('pages fixes non générées :', (r.stderr or r.stdout)[-400:])
    if os.path.exists(fa): os.remove(fa)
except Exception as e:
    print('pages fixes non générées :', e)
# application installable (0.17.0-alpha.1) : manifeste, icônes, service worker (ouverture sans réseau)
page = ('<!doctype html>\n<html lang="fr">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">\n'
        f'<meta name="description" content="Œnotrack {version} — traçabilité de cuverie et de chai">\n<meta name="theme-color" content="#1E242B">\n'
        '<link rel="manifest" href="manifest.webmanifest">\n<link rel="icon" type="image/png" sizes="192x192" href="icone-192.png">\n<link rel="apple-touch-icon" href="apple-touch-icon.png">\n'
        '<meta name="apple-mobile-web-app-capable" content="yes">\n<meta name="mobile-web-app-capable" content="yes">\n<meta name="apple-mobile-web-app-title" content="Œnotrack">\n'
        f'<link rel="icon" href="{icone}" sizes="any">\n</head>\n<body>\n' + (f'<noscript>{noscript}</noscript>\n' if noscript else '') + src + '\n</body>\n</html>\n')
open(os.path.join(dossier, 'index.html'), 'w', encoding='utf8').write(page)
manifeste = {"name": "Œnotrack — traçabilité de cuverie et de chai", "short_name": "Œnotrack", "description": "Traçabilité de cuverie et de chai : cuves, lots, opérations, registres, jaugeage.",
             "lang": "fr", "dir": "ltr", "start_url": "./", "scope": "./", "id": "./", "display": "standalone", "display_override": ["standalone", "minimal-ui"], "orientation": "any",
             "background_color": "#1E242B", "theme_color": "#1E242B", "categories": ["business", "productivity"],
             "icons": [{"src": "icone-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any"}, {"src": "icone-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any"},
                       {"src": "icone-maskable-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable"}]}
json.dump(manifeste, open(os.path.join(dossier, 'manifest.webmanifest'), 'w', encoding='utf8'), ensure_ascii=False, indent=2)
import shutil
for n in ['icone-192.png', 'icone-512.png', 'icone-maskable-512.png', 'apple-touch-icon.png']: shutil.copy(os.path.join(racine, 'tools', 'icones', n), os.path.join(dossier, n))
import hashlib
empreinte = hashlib.sha1(page.encode('utf8') + b''.join(open(os.path.join(dossier, n), 'rb').read() for n in ['icone-192.png', 'icone-512.png', 'icone-maskable-512.png', 'apple-touch-icon.png'])).hexdigest()[:8]
sw = """// Œnotrack — service worker : l'application s'ouvre même sans réseau (cave, vignes) ; nouvelle version prise dès que le réseau est là
const VERSION = 'oenotrack-__VERSION__';
const COEUR = ['./', './index.html', './manifest.webmanifest', './icone-192.png', './icone-512.png', './icone-maskable-512.png', './apple-touch-icon.png'];
const CDN = /^https:\\/\\/(cdnjs\\.cloudflare\\.com|cdn\\.jsdelivr\\.net|unpkg\\.com|cdn\\.tailwindcss\\.com|fonts\\.googleapis\\.com|fonts\\.gstatic\\.com)\\//;
self.addEventListener('install', (e) => { e.waitUntil(caches.open(VERSION).then((c) => c.addAll(COEUR)).catch(() => null).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k.startsWith('oenotrack-') && k !== VERSION).map((k) => caches.delete(k)))).then(() => self.clients.claim())); });
const garder = (r, rep) => { if (rep && (rep.ok || rep.type === 'opaque')) { const cp = rep.clone(); caches.open(VERSION).then((c) => c.put(r, cp)).catch(() => null); } return rep; };
self.addEventListener('fetch', (e) => {
  const r = e.request; if (r.method !== 'GET') return; const u = new URL(r.url);
  if (u.origin === self.location.origin) {
    if (r.mode === 'navigate' || /\\/(index\\.html)?$/.test(u.pathname) || u.pathname.endsWith('config.json')) { // la page et config.json : le réseau d'abord
      const cle = r.mode === 'navigate' ? './index.html' : r;
      e.respondWith(fetch(r).then((rep) => garder(cle, rep)).catch(() => caches.match(cle).then((x) => x || caches.match('./')))); return;
    }
    e.respondWith(caches.match(r).then((x) => x || fetch(r).then((rep) => garder(r, rep)))); return;
  }
  if (CDN.test(r.url)) e.respondWith(caches.match(r).then((x) => x || fetch(r).then((rep) => garder(r, rep)))); // bibliothèques (versions figées)
  // Google Drive, OneDrive, Dropbox : jamais interceptés
});
""".replace('__VERSION__', version + '-' + empreinte)
open(os.path.join(dossier, 'sw.js'), 'w', encoding='utf8').write(sw)
lisez = f"""ŒNOTRACK EN LIGNE ({version})
==============================

Ce dossier contient Œnotrack prêt à être mis en ligne :
  - index.html  : l'application, avec sa page d'accueil (présentation d'Œnotrack, à la toute première ouverture) ;
  - config.json : les identifiants publics de Google, Microsoft et Dropbox (à remplir, voir étape 3) ;
  - confidentialite.html, mentions-legales.html, cgu.html, licence.html : les informations légales en pages fixes,
    lisibles sans JavaScript (pour les écrans de connexion Google, Microsoft, Dropbox et les moteurs de recherche) ;
  - manifest.webmanifest, sw.js et les icônes : pour installer Œnotrack comme une application (étape 5).
Mise à jour : remplacez index.html, sw.js et les pages .html (et ajoutez les fichiers nouveaux), gardez votre config.json.

1. METTRE EN LIGNE (gratuit, environ 5 minutes)
   - Créez un compte sur https://www.netlify.com puis ouvrez https://app.netlify.com/drop
   - Glissez-y ce dossier « oenotrack-web » (décompressé).
   - Netlify affiche l'adresse du site (https://xxxx.netlify.app). Renommez-la :
     Site configuration > Change site name (ex. oenotrack-mondomaine).
   - Nouvelle version d'Œnotrack : remplacez SEULEMENT index.html dans votre dossier (gardez votre config.json
     rempli), puis onglet Deploys : glissez à nouveau le dossier. Vos données ne bougent pas (elles sont sur le Drive
     et dans chaque appareil).

2. OUVRIR ŒNOTRACK EN LIGNE
   - Ouvrez votre adresse : Paramètres > Sauvegarde & Drive > « Stockage sur votre Drive ».
   - Dépliez « Identifiants des services » : l'adresse exacte à déclarer y est affichée,
     avec les guides pas à pas pour Google Drive, OneDrive et Dropbox.

3. DÉCLARER ŒNOTRACK CHEZ VOTRE DRIVE (une fois, environ 10 minutes par service)
   - Google Drive : console.cloud.google.com (projet, API Google Drive, écran de consentement,
     utilisateurs test, ID client OAuth « Application Web » avec votre adresse en origine autorisée).
   - OneDrive : portal.azure.com > Inscriptions d'applications (application monopage, adresse de retour,
     autorisation Files.ReadWrite.All).
   - Dropbox : dropbox.com/developers/apps (Scoped access, Full Dropbox, Redirect URI, PKCE autorisé).
   Collez chaque identifiant dans Œnotrack (champ correspondant), puis « Télécharger config.json » :
   remplacez le config.json de ce dossier et remettez le dossier en ligne (étape 1) pour que tous
   les appareils l'aient.

4. CHOISIR LE DOSSIER DU DRIVE
   - « Se connecter » sur votre service, puis choisissez (ou créez) le dossier : Œnotrack y enregistre
     oenotrack-base.json, documents/ et historique/, et les tient à jour automatiquement.
   - Partagez ce dossier (en modification) avec vos collaborateurs : chacun se connecte avec son compte
     et choisit le même dossier (« Partagés avec moi »).

5. INSTALLER L'APPLICATION (téléphone, tablette, ordinateur — sans magasin d'applications)
   - Android : ouvrez votre adresse dans Chrome, menu ⋮ > « Installer l'application » (ou « Ajouter à l'écran d'accueil »).
   - iPhone / iPad : dans Safari, bouton Partager > « Sur l'écran d'accueil ».
   - Ordinateur (Chrome, Edge) : icône d'installation à droite de la barre d'adresse.
   Œnotrack s'ouvre alors en plein écran depuis l'écran d'accueil, même sans réseau, et se met à jour tout seul.

Autres Drive (iCloud Drive, kDrive, pCloud…) : « Dossier de l'ordinateur » (Chrome ou Edge sur ordinateur)
avec le dossier que l'application du Drive crée sur l'ordinateur.

HÉBERGEUR WEB CLASSIQUE (OVHcloud, o2switch, Scaleway…)
   Envoyez tous les fichiers de ce dossier dans le dossier du site (souvent « www ») de votre hébergement,
   avec le gestionnaire de fichiers de l'hébergeur ou un logiciel FTP (FileZilla). L'adresse doit être
   en https (certificat SSL, gratuit chez la plupart des hébergeurs).

6. MENTIONS LÉGALES (obligatoires pour un site en ligne)
   - Les pages « Mentions légales », « Confidentialité », « CGU » et « Code source & licence » s'affichent
     en bas de chaque écran, et aux adresses …/#mentions-legales, …/#confidentialite, …/#cgu, …/#licence.
   - Les coordonnées du site (éditeur, contact, hébergeur) se trouvent dans config.json, rubrique « mentions »
     (elles ne se règlent pas dans l'application) :
     "mentions": {{ "editeur": {{ "statut": "particulier", "nom": "…", "email": "…" }},
                   "hebergeur": {{ "id": "ovh" }}, "site": "https://…", "depot": "https://github.com/…" }}
     (statut : particulier, pro ou association — un professionnel ajoute "adresse", "tel" et "immatriculation" ;
      hébergeurs connus : ovh, o2switch, scaleway, netlify, github ; sinon "nom", "adresse", "tel").
     Gardez les identifiants Drive déjà présents dans le même fichier (« google », « microsoft », « dropbox »).

   - Les pages fixes (confidentialite.html, mentions-legales.html…) reprennent le config.json du paquet : après un
     changement de la rubrique « mentions », refaites le paquet pour les mettre à jour.

7. CODE SOURCE ET LICENCE
   - Œnotrack est un logiciel libre (GNU AGPL v3 ou ultérieure) : voir LICENCE.txt.
   - code-source.zip : le code de cette version, proposé aux utilisateurs depuis la page
     « Code source & licence » (si vous mettez en ligne une version modifiée, la licence l'exige).
   - Le nom « Œnotrack » et son logo ne sont pas couverts par la licence.

8. CONNEXION GOOGLE, MICROSOFT ET DROPBOX POUR TOUS (site officiel : oenotrack.fr)
   - Page d'accueil à déclarer : https://oenotrack.fr/ (présentation d'Œnotrack, son nom exact et son fonctionnement).
   - Politique de confidentialité : https://oenotrack.fr/confidentialite.html ; conditions d'utilisation : https://oenotrack.fr/cgu.html.
   - Google (écran de consentement OAuth) : nom de l'application « Œnotrack », ces adresses, domaine autorisé oenotrack.fr
     vérifié dans Google Search Console. Œnotrack demande l'accès complet au Drive, une autorisation « restreinte » chez
     Google : la vérification de l'application est plus poussée (justification, vidéo de démonstration).
   - Microsoft (Entra ID) et Dropbox : mêmes adresses dans les réglages de l'application (Branding / Settings).
"""
open(os.path.join(dossier, 'LISEZ-MOI.txt'), 'w', encoding='utf8').write(lisez)
# licence et code source de cette version (depuis 0.21.0-alpha.1) : sans les notes de travail ni le test qui lit des documents privés de l'exploitation
shutil.copy(os.path.join(racine, 'LICENCE.txt'), os.path.join(dossier, 'LICENCE.txt'))
EXCLUS_RACINE = {'dist', 'NOTES.md', 'published-fragment.html', '.git'}
EXCLUS = {os.path.join('test', 't37.mjs')}
nom_src = 'oenotrack-' + version.replace(' ', '-')
cs = os.path.join(dossier, 'code-source.zip')
with zipfile.ZipFile(cs, 'w', zipfile.ZIP_DEFLATED) as z:
    for base, dirs, fichiers in os.walk(racine):
        rel = os.path.relpath(base, racine)
        if rel == '.': dirs[:] = [d for d in dirs if d not in EXCLUS_RACINE]
        dirs[:] = sorted(d for d in dirs if d not in ('__pycache__', 'node_modules', '.git'))
        for f in sorted(fichiers):
            r = os.path.normpath(os.path.join(rel, f))
            if (rel == '.' and f in EXCLUS_RACINE) or r in EXCLUS: continue
            z.write(os.path.join(base, f), f'{nom_src}/{r}')
zp = os.path.join(racine, 'dist', 'web', 'oenotrack-web.zip')
with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as z:
    for n in ['index.html', 'config.json', 'LISEZ-MOI.txt', 'LICENCE.txt', 'code-source.zip', 'manifest.webmanifest', 'sw.js', 'icone-192.png', 'icone-512.png', 'icone-maskable-512.png', 'apple-touch-icon.png'] + [x for x in PAGES_FIXES if os.path.exists(os.path.join(dossier, x))]: z.write(os.path.join(dossier, n), f'oenotrack-web/{n}')
print('paquet', version, os.path.getsize(zp) // 1024, 'Ko')

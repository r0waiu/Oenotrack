# Œnotrack — traçabilité de cuverie et de chai

Œnotrack est un logiciel libre de traçabilité pour les vignerons : plan de cuverie, lots et portions,
opérations (entrées de vendange et de moûts, débourbage, levurage, soutirages, assemblages, froid,
filtration…), tirage, dégorgement, intrants et leurs fiches techniques / FDS, hygiène, analyses,
jaugeage, registres et exports, traçabilité ascendante et descendante.

- **Tout dans le navigateur** : les données restent sur l'appareil (stockage du navigateur) ;
  synchronisation facultative avec le Drive de l'utilisateur (Google Drive, OneDrive, Dropbox).
- **Une seule page** : l'application est un fichier HTML autonome (`dist/cuverie.html`),
  installable comme une application (téléphone, tablette, ordinateur).
- **Assistant IA facultatif**, avec la propre clé API de chaque utilisateur (Claude, ChatGPT,
  Gemini, Mistral…), gardée sur son appareil.

Version en cours : voir `APP_VERSION` dans `src/10-core.js` et le journal des nouveautés dans l'application.

## Construire

```
node build.mjs                 # src/*.js(x) → dist/cuverie.html
python3 tools/paquet-web.py    # dist/web/oenotrack-web/ : site prêt à mettre en ligne (+ zip)
node test/engine.test.js       # tests du moteur (compatibilité des bases comprise)
```

Les fichiers de `src/` sont concaténés dans l'ordre de leur nom puis compilés par esbuild
(`build.mjs`). Les tests d'interface (`test/t*.mjs`) utilisent Playwright.

## Mettre en ligne

Envoyez le contenu de `dist/web/oenotrack-web/` chez un hébergeur de sites statiques. Les
coordonnées du site (éditeur, hébergeur, contact) se mettent dans `config.json`, rubrique
`mentions` (exemple dans `LISEZ-MOI.txt`), à côté d'`index.html` : chaque personne qui met en
ligne sa propre copie indique les siennes.

## Licence

Œnotrack est distribué sous licence **GNU Affero General Public License v3.0 ou ultérieure**
(voir `LICENCE.txt` et https://www.gnu.org/licenses/agpl-3.0.html). Si vous mettez en ligne une
version modifiée, vous devez en proposer le code source à ses utilisateurs.

Le nom « Œnotrack » et son logo ne sont pas couverts par la licence : une version modifiée
diffusée doit porter un autre nom et un autre logo (elle peut se dire « basée sur Œnotrack »).

Les composants d'autres auteurs restent sous leur propre licence (liste dans l'application :
Informations légales › Code source & licence).
